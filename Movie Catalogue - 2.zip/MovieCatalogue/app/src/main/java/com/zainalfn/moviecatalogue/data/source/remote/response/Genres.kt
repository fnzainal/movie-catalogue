package com.zainalfn.moviecatalogue.data.source.remote.response

data class Genres(
    val id: Int?,
    val name: String?,
)
