package com.zainalfn.moviecatalogue.data.source.remote.response

data class MoviesResponse(
    val results: ArrayList<MovieDetailResponse>
)
