package com.zainalfn.moviecatalogue.data.source.remote.response

data class TvShowsResponse(
    val results: ArrayList<TvShowDetailResponse>
)
